<footer>
   <div>Webfoco Marketing Digital de Performance © 2023 – Todos os Direitos Reservados - Desenvolvedor: Tawan Rio</div>
</footer>
<script src="./assets/js/view/app.js"></script>

</body>

</html>